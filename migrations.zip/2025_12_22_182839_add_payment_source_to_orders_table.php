<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Content removed due to copy-paste error (was duplicating add_role_to_users)
        // Table 'orders' already has payment_method and payment_id from create_orders_table
    }

    public function down(): void
    {
        //
    }
};